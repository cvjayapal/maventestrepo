
public class Jenkins {

	public static void main(String[] args) {
		
		System.out.println("Hello we are here");
	}
	
	public static void run(int i){
	
	}
}
